docker run -d --env-file openrc.sh --name gateway -p 80:8000 gateway
