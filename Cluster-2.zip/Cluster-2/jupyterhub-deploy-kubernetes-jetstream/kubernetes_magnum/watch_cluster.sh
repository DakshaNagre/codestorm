watch -d -n 20 openstack coe cluster list
