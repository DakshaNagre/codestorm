rm -r kubectl_secret
mkdir kubectl_secret
cd kubectl_secret
openstack coe cluster config k8s
cd ..
