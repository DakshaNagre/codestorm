openstack coe cluster delete k8s
