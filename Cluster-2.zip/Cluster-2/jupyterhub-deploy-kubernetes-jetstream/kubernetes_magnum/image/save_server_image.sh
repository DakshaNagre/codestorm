openstack server image create --name Fedora-AtomicHost-28-20180625-updated-$(date +"%Y%m%d") fedora_update
