CVMFS on Kubernetes
===================

See the tutorial at <https://zonca.github.io>
